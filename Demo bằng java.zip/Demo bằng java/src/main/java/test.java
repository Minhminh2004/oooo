import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class test {
    public static void main(String[] args) {
    // Thiết lập đường dẫn tới ChromeDriver nếu cần
    // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

    // Khởi tạo WebDriver
    WebDriver driver = new ChromeDriver();
try{
            // Mở trang login
            driver.get("https://www.sport9.vn/login");

            // Tìm và nhập Username
            WebElement usernameField = driver.findElement(By.id("Email"));
            usernameField.sendKeys("yourUsername");

            // Tìm và nhập Password
            WebElement passwordField = driver.findElement(By.id("Password"));
            passwordField.sendKeys("yourPassword");

            // Click vào nút Login
            WebElement loginButton = driver.findElement(By.cssSelector(".button-1.login-button"));
            loginButton.click();

        Thread.sleep(3000);

        // Kiểm tra kết quả login
        String currentUrl = driver.getCurrentUrl();
        if (currentUrl.contains("customer")) {  // Sport9.vn sẽ redirect tới "/customer/info" sau login
            System.out.println("Đăng nhập thành công!");
        } else {
            System.out.println("Đăng nhập thất bại.");
        }

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Đóng trình duyệt
        driver.quit();
    }

            // Kiểm tra kết quả login (ví dụ: kiểm tra URL hoặc 1 element đặc biệt)
            String currentUrl = driver.getCurrentUrl();
            if (currentUrl.contains("dashboard")) {
                System.out.println("Đăng nhập thành công!");
            } else {
                System.out.println("Đăng nhập thất bại.");
            }
    }
}
